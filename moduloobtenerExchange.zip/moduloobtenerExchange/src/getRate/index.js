import exchange from "./exchange.js";

const er = new exchange();

export function exchangeEth() {
  return er;
}
